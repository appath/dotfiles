#Проверка обновлений UBUNTU:
$ sudo apt update
$ sudo apt upgrade
$ sudo apt dist-upgrade
$ sudo apt autoremove

#Заголовочные файлы ядра
$ sudo apt install build-essential linux-headers-$(uname -r)

#VMBOX video driver
$ sudo apt install virtualbox-guest-x11
$ sudo mount /dev/cdrom /mnt
$ cd /mnt
$ sudo ./VBoxLinuxAdditions.run
$ sudo umount /dev/cdrom /mnt
$ sudo reboot

#DWM $PKG зависимости, источник из сети:
$ sudo apt install xorg libx11-dev libxft-dev libxinerama-dev gcc g++ libncurses5-dev 

#UTL $PKG
$ sudo apt install zsh rxvt-unicode vim mc make fakeroot fontconfig git

#Сменить командную оболочку
$ sudo chsh -s /bin/zsh vm

#
$ mkdir .git && cd .git
$ git clone https://github.com/appath/dotfiles && cd
$ sudo apt install unzip
$ cp -r .git/dotfiles/dwm_linux_x64.zip ~/ && unzip dwm_linux_x64.zip

#Прикладные программы
$ cd .fonts && mkfontdir && mkfontscale && fc-cache -fv
$ sudo rm -f /etc/fonts/conf.d/70-no-bitmaps.conf

#Привилегии
$ cd .bash/status_
$ chmod +x start && cd sections
$ chmod +x clock_ && chmod +x keyboard_layout_ && chmod +x memory_

#Сборка
$ cd .makebuild\dwm_custom
$ make && sudo make clean install
$ cd && cd dmenu_custom
$ make && sudo make clean install