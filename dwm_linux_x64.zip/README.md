#Проверка обновлений UBUNTU:
$ sudo apt update
$ sudo apt upgrade
$ sudo apt dist-upgrade
$ sudo apt autoremove

#VMBOX video driver
$ sudo apt install virtualbox-guest-x11
#Заголовочные файлы ядра
#UBUNTU
$ sudo apt install build-essential linux-headers-$(uname -r)
#KALI
$ sudo apt install -y linux-headers-$(uname -r)
#MOUNT Guest Additions 
$ sudo mount /dev/cdrom /mnt
$ cd /mnt
$ sudo ./VBoxLinuxAdditions.run
$ sudo umount /dev/cdrom /mnt
$ sudo reboot

#X11
$ sudo apt install xorg

#UTL $PKG
$ sudo apt install zsh rxvt-unicode vim mc fontconfig git

#Сменить командную оболочку
$ sudo chsh -s /bin/zsh vm

#
$ mkdir .git && cd .git
$ git clone https://github.com/appath/dotfiles && cd
$ sudo apt install unzip
$ cp -r .git/dotfiles/dwm_linux_x64.zip ~/ && unzip dwm_linux_x64.zip

#Прикладные программы
$ cd .fonts && mkfontdir && mkfontscale && fc-cache -fv
$ sudo rm -f /etc/fonts/conf.d/70-no-bitmaps.conf

#Привилегии
$ cd .bash/status_
$ chmod +x start && cd sections
$ chmod +x clock_ && chmod +x keyboard_layout_ && chmod +x memory_

#Сборка
$ sudo apt install make fakeroot libx11-dev libxft-dev libxinerama-dev libncurses5-dev gcc g++
$ cd .makebuild\dwm_custom
$ make && sudo make clean install
$ cd && cd dmenu_custom
$ make && sudo make clean install