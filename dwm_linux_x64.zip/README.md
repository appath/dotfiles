#Обновление UBUNTU:
$ sudo apt update
$ sudo apt upgrade
$ sudo apt dist-upgrade
$ sudo apt autoremove

#
$ sudo apt install build-essential gcc g++ libncurses5-dev linux-headers-$(uname -r)

#VMBOX video driver
$ sudo mount /dev/cdrom /mnt
$ cd /mnt
$ sudo ./VBoxLinuxAdditions.run

#DWM $PKG зависимости, источник из сети:
$ sudo apt install git xorg libx11-dev libxft-dev libxinerama-dev make fakeroot

#UTL $PKG
$ sudo apt install fontconfig zsh rxvt-unicode vim mc

