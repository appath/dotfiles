
	chmod +x start