
	chmod a+x start