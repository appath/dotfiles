#Проверка обновлений UBUNTU = Kali Linux:
#Checking for updates UBUNTU = Kali Linux:
$ sudo apt update
$ sudo apt upgrade
$ sudo apt dist-upgrade
$ sudo apt autoremove

#VMBOX video driver
$ sudo apt install virtualbox-guest-x11
#Заголовочные файлы ядра
#Kernel Header Files
#UBUNTU
$ sudo apt install build-essential linux-headers-$(uname -r)
#KALI
$ sudo apt install -y linux-headers-$(uname -r)

#X11
$ sudo apt install xorg

#UTL $PKG
$ sudo apt install zsh rxvt-unicode vim mc fontconfig git

#Сменить командную оболочк
#Change Command Shell
$ sudo chsh -s /bin/zsh vm

#Клонирование
#Cloning
$ mkdir .git && cd .git
$ git clone https://github.com/appath/dotfiles && cd

#Распаковка
#Unpacking
$ sudo apt install unzip
$ cp -r .git/dotfiles/dwm_linux_x64.zip ~/

#Протестировать архив
#Test archive
$ unzip -tq dwm_linux_x64.zip
$ unzip dwm_linux_x64.zip

#Прикладные программы
#Application programs
$ cd .fonts && mkfontdir && mkfontscale && fc-cache -fv && cd
$ sudo rm -f /etc/fonts/conf.d/70-no-bitmaps.conf

#Привилегии
#Privilege
$ cd .bash/status_
$ chmod +x start && cd sections
$ chmod +x clock_ && chmod +x keyboard_layout_ && chmod +x memory_ && cd

#Сборка
#Assembly
$ sudo apt install make fakeroot gcc g++ libx11-dev libxft-dev libxinerama-dev
$ cd .makebuild\dwm_custom
$ make && sudo make clean install && cd .. & cd dmenu_custom
$ make && sudo make clean install && cd

#Запуск X11
#X11 launch
$ startx

