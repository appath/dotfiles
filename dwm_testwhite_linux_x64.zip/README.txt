#Checking for updates UBUNTU = Kali Linux:
$ sudo apt update
$ sudo apt upgrade
$ sudo apt dist-upgrade
$ sudo apt autoremove

#Remove UBUNTU
$ sudo apt remove plymouth

$ sudo dpkg-reconfigure console-setup

#Kernel Header Files
#UBUNTU
$ sudo apt install build-essential linux-headers-$(uname -r)
#KALI
$ sudo apt install -y linux-headers-$(uname -r)

#VMBOX video driver
$ sudo apt install virtualbox-guest-x11
#VWWARE video driver
$ sudo apt install open-vm-tools

#X11
$ sudo apt install xorg

#UTL $PKG
$ sudo apt install zsh rxvt-unicode vim mc fontconfig git

#Change Command Shell
$ sudo chsh -s /bin/zsh vm

#Cloning
$ mkdir .git && cd .git
$ git clone https://github.com/appath/dotfiles && cd

#Unpacking
$ sudo apt install unzip
$ cp -r .git/dotfiles/dwm_linux_x64.zip ~/

#Test archive
$ unzip -tq dwm_linux_x64.zip
$ unzip dwm_linux_x64.zip

#Application programs
$ cd .fonts && mkfontdir && mkfontscale && fc-cache -fv && cd
$ sudo rm -f /etc/fonts/conf.d/70-no-bitmaps.conf

#Privilege
$ cd .bin/status_
$ chmod +x start && cd sections
$ chmod +x clock_ && chmod +x keyboard_layout_ && chmod +x memory_ && cd

#Assembly
$ sudo apt install make fakeroot gcc g++ libx11-dev libxft-dev libxinerama-dev
$ cd .makebuild\dwm_custom
$ make && sudo make clean install && cd .. && cd dmenu_custom
$ make && sudo make clean install && cd

#X11 launch
$ startx

