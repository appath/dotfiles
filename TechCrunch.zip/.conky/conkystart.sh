#!/bin/bash
sleep 30 &
conky -c ~/.conky/TechCrunch &
exit 0
